<?php return array(
    'root' => array(
        'name' => 'project/plugin',
        'pretty_version' => 'dev-beta',
        'version' => 'dev-beta',
        'reference' => '09020db0d92d6766fc77a16215049a9cb83d5838',
        'type' => 'project',
        'install_path' => __DIR__ . '/../../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        'project/plugin' => array(
            'pretty_version' => 'dev-beta',
            'version' => 'dev-beta',
            'reference' => '09020db0d92d6766fc77a16215049a9cb83d5838',
            'type' => 'project',
            'install_path' => __DIR__ . '/../../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
