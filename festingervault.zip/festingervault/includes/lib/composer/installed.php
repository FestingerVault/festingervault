<?php return array(
    'root' => array(
        'name' => 'project/plugin',
        'pretty_version' => 'dev-beta',
        'version' => 'dev-beta',
        'reference' => 'f6ede183e69d2ed15d07dccb8dc9a5ba2669a2c9',
        'type' => 'project',
        'install_path' => __DIR__ . '/../../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        'project/plugin' => array(
            'pretty_version' => 'dev-beta',
            'version' => 'dev-beta',
            'reference' => 'f6ede183e69d2ed15d07dccb8dc9a5ba2669a2c9',
            'type' => 'project',
            'install_path' => __DIR__ . '/../../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
