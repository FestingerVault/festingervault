<?php return array(
    'root' => array(
        'name' => 'project/plugin',
        'pretty_version' => 'dev-main',
        'version' => 'dev-main',
        'reference' => 'f2b6c3e78f44234cba438278a39b1e8ff5be1345',
        'type' => 'project',
        'install_path' => __DIR__ . '/../../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        'project/plugin' => array(
            'pretty_version' => 'dev-main',
            'version' => 'dev-main',
            'reference' => 'f2b6c3e78f44234cba438278a39b1e8ff5be1345',
            'type' => 'project',
            'install_path' => __DIR__ . '/../../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
